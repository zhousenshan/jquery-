package com.mayikt.weixin.input.dto;

public class AppInpDTO {

}
