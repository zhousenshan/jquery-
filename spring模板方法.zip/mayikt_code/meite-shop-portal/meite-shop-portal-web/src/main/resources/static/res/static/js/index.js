function demoA(){
	alert('mayikt');
	
}