package com.mayikt.web.constants;

public interface WebConstants {

	String LOGIN_TOKEN_COOKIENAME = "login.pc.token";
	String LOGIN_QQ_OPENID = "qq_openid";
}
